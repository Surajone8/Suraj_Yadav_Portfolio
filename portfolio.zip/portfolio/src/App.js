import './App.css';
import BackgroundVideo from './components/BackgroundVideo';

function App() {
  return (
    <>
        <BackgroundVideo />
    </>
  );
}

export default App;
